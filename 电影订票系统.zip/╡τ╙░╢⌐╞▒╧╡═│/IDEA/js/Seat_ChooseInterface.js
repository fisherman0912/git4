var seat_check = new Array();
for (let i = 0; i < 5; i++) {
    seat_check[i] = new Array();
    for (let j = 0; j < 8; j++) {
    seat_check[i][j] = 0;
    }
}
var seat_finalBook = new Array();
for (let i = 0; i < 5; i++) {
    seat_finalBook[i] = new Array();
    for (let j = 0; j < 8; j++) {
        seat_finalBook[i][j] = 0;
    }
}


function seat_choose(row, col) {
    document.getElementById("stButton_pay").disabled = true;
    var id = row + "-" + col;
    if (seat_check[row - 1][col - 1] == 0) {
        document.getElementById(id).src = "../image/seat_select.png";
        seat_check[row - 1][col - 1] = 1;
    } else if (seat_check[row - 1][col - 1] == 1){
        document.getElementById(id).src = "../image/seat.png";
        seat_check[row - 1][col - 1] = 0;
    }
}

function seat_show() {
    document.getElementById("seat_selected").innerHTML = "";
    var seat = document.getElementById("seat_selected");
    for (let i = 0; i < 5; i++) {
        for (let j = 0; j < 8; j++) {
            if (seat_check[i][j] == 1) {
                var choice = (i + 1) + "排" + (j + 1) + "座";
                document.getElementById("seat_selected").innerHTML = seat.innerText + " " + choice;
            }
        }
    }
    document.getElementById("stButton_pay").disabled = false;
}

function seat_pay() {
    for (let i = 0; i < 5; i++) {
        for (let j = 0; j < 8; j++) {
            if (seat_check[i][j] == 1) {
                var id = (i + 1) + "-" + (j + 1);
                document.getElementById(id).src = "../image/seat_sold.png";
                seat_check[i][j] = 2;
                seat_finalBook[i][j] = 1;
            }
        }
    }
    window.location.href = "Movie_PayDispose.php?s_c=" + seat_check + "&s_fB=" + seat_finalBook;
}