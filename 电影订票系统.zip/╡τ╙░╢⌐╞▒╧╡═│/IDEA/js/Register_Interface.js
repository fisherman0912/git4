window.onload = function () {
    document.getElementById('rmp').onblur = check_rmp;
    document.getElementById('run').onblur = check_run;
    document.getElementById('ric').onblur = check_ric;
    document.getElementById('rrpw').onblur = check_rpw;
    document.getElementById('register').onmouseover = submit_onoroff;
}

function check_rmp() {
    var r_mp = document.getElementById('rmp').value;
    var xhr1 = new XMLHttpRequest();
    xhr1.onreadystatechange = function () {
        receiveMsg_rmp(xhr1);
    };
    xhr1.open('GET', '.././php/Check_Rmp.php?rmp=' + r_mp, true);
    xhr1.send();
}

function receiveMsg_rmp(xhr) {
    if(xhr.readyState == 4 && xhr.status == 200) {
        if(xhr.responseText == 1) {
            document.getElementById("show_crmp").innerHTML = "该手机号未注册！";
            document.getElementById("show_crmp").className = "yes";
            document.getElementById("register").disabled = false;
        } else {
            document.getElementById("show_crmp").innerHTML = "该手机号已注册！";
            document.getElementById("show_crmp").className = "no";
            document.getElementById("register").disabled = true;
        }
    }
}

function check_run() {
    var r_un = document.getElementById('run').value;
    var xhr2 = new XMLHttpRequest();
    xhr2.onreadystatechange = function () {
        receiveMsg_run(xhr2);
    };
    xhr2.open('GET', '.././php/Check_Run.php?run=' + r_un, true);
    xhr2.send();
}

function receiveMsg_run(xhr) {
    if(xhr.readyState == 4 && xhr.status == 200) {
        if(xhr.responseText == 1) {
            document.getElementById("show_crun").innerHTML = "该用户名可使用！";
            document.getElementById("show_crun").className = "yes";
            document.getElementById("register").disabled = false;
        } else {
            document.getElementById("show_crun").innerHTML = "该用户名已存在！";
            document.getElementById("show_crun").className = "no";
            document.getElementById("register").disabled = true;
        }
    }
}

function check_ric() {
    var r_ic = document.getElementById('ric').value;
    var xhr3 = new XMLHttpRequest();
    xhr3.onreadystatechange = function () {
        receiveMsg_ric(xhr3);
    };
    xhr3.open('GET', '.././php/Check_Ric.php?ric=' + r_ic, true);
    xhr3.send();
}

function receiveMsg_ric(xhr) {
    if(xhr.readyState == 4 && xhr.status == 200) {
        if(xhr.responseText == 1) {
            document.getElementById("show_cric").innerHTML = "该身份证号未注册！";
            document.getElementById("show_cric").className = "yes"
            document.getElementById("register").disabled = false;
        } else {
            document.getElementById("show_cric").innerHTML = "该身份证号已注册！";
            document.getElementById("show_cric").className = "no";
            document.getElementById("register").disabled = true;
        }
    }
}

function check_rpw() {
    var rpw = document.getElementById("rpw").value;
    var rrpw = document.getElementById("rrpw").value;
    if(rpw != rrpw) {
        document.getElementById("show_crpw").innerHTML = "该确认密码错误！";
        document.getElementById("show_crpw").className = "no"
        document.getElementById("register").disabled = true;
    } else {
        document.getElementById("show_crpw").innerHTML = "该确认密码正确！";
        document.getElementById("show_crpw").className = "yes"
        document.getElementById("register").disabled = false;
    }
}

function submit_onoroff() {
    if(document.getElementById("show_crmp").innerHTML == "该手机号未注册！" &&
        document.getElementById("show_crun").innerHTML == "该用户名可使用！" &&
        document.getElementById("show_cric").innerHTML == "该身份证号未注册！" &&
    document.getElementById("show_crpw").innerHTML == "该确认密码正确！") {
        document.getElementById("register").disabled = false;
    } else {
        document.getElementById("register").disabled = true;
    }
}