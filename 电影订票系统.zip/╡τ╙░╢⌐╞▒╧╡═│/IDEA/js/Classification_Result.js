function classify(value1, value2, value3) {
    window.location.href = "Classification_Result.php?type=" + value1 + "&page=" + value2 + "&interval=" + value3;
}

function show(value) {
    window.location.href = "SM_Show.php?M_ID=" + value;
}

function previous_page(value1, value2, value3) {
    window.location.href = "Classification_Result.php?type=" + value1 + "&page=" + (value2 - 1) + "&interval=" + value3;
}

function next_page(value1, value2, value3) {
    window.location.href = "Classification_Result.php?type=" + value1 + "&page=" + (value2 + 1) + "&interval=" + value3;
}