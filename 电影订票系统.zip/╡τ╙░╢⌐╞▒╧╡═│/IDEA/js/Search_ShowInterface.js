function enter(value) {
    window.location.href = "SM_Show.php?M_ID=" + value;
}