function session_choice(value1, value2, value3, value4) {
    window.location.href = "Seat_ChooseInterface.php?s_c=" + value1 + "&a_c=" + value2 + "&p_t=" + value3
    + "&r_t=" + value4;
}