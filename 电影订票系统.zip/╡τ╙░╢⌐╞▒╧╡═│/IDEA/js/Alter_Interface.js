window.onload = function () {
    document.getElementById('aun').onblur = check_run;
    document.getElementById('alter').onmouseover = submit_onoroff;
}

function check_run() {
    var a_un = document.getElementById('aun').value;
    var xhr = new XMLHttpRequest();
    xhr.onreadystatechange = function () {
        receiveMsg_aun(xhr);
    };
    xhr.open('GET', '.././php/Check_Run.php?run=' + a_un, true);
    xhr.send();
}

function receiveMsg_aun(xhr) {
    if(xhr.readyState == 4 && xhr.status == 200) {
        if(xhr.responseText == 1) {
            document.getElementById("show_caun").innerHTML = "该用户名可使用！";
            document.getElementById("show_caun").className = "yes";
            document.getElementById("alter").disabled = false;
        } else {
            document.getElementById("show_caun").innerHTML = "该用户名已存在！";
            document.getElementById("show_caun").className = "no";
            document.getElementById("alter").disabled = true;
        }
    }
}

function submit_onoroff() {
    if(document.getElementById("show_caun").innerHTML == "该用户名可使用！") {
        document.getElementById("alter").disabled = false;
    } else {
        document.getElementById("alter").disabled = true;
    }
}