function classify(value1, value2, value3) {
    window.location.href = "Classification_Result.php?type=" + value1 + "&page=" + value2 + "&interval=" + value3;
}

function ing_show(id) {
    document.ingMovie.M_ID.value = id;
}

function will_show(id) {
    document.willMovie.M_ID.value = id;
}