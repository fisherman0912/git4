function search() {
    if (event.keyCode == 13) {
        var keyword = document.getElementById("search_text").value;
        window.location.href = "Search_ShowInterface.php?kw=" + keyword;
    }
}