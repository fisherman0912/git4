<?php
require 'mysql.php';
$mp = $_POST['lmp'];
$pw = $_POST['lpw'];
$rl = $_POST['role'];
if($mp == null || $pw == null) {
    echo "<script>alert('手机号或密码不能为空！');parent.location.href='../html/Login_Interface.html';</script>";
}
if($rl == '管理员') {
    if($mp == '13829035695' && $pw == 'xzj000811') {
        echo "<script>alert('登录成功！欢迎您 xzj管理员！');parent.location.href='Administrator_Interface.php';</script>";
    } else {
        echo "<script>alert('输入的手机号或密码错误！请确认管理员身份！');parent.location.href='../html/Login_Interface.html';</script>";
    }
} else {
    $check_str = "select 手机号, 密码, 用户名 from 用户信息表 where 手机号 = '$mp' and 密码 = '$pw'";
    $check_obj = new mysql_DB();
    $check_result = $check_obj->execSQL($check_str);
    $user_information = $check_result->fetch_assoc();
    session_start();
    $_SESSION['un'] = $user_information['用户名'];
    $check_row = $check_result->num_rows;
    if($check_row != 0) {
        echo "<script>alert('登录成功！欢迎您 {$_SESSION['un']}用户！');parent.location.href='User_MovieInterface.php';</script>";
    } else {
        echo "<script>alert('输入的手机号或密码错误！');parent.location.href='../html/Login_Interface.html';</script>";
    }
}
?>