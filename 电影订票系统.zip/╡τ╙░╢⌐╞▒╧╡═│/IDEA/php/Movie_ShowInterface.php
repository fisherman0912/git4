<?php
require 'mysql.php';
session_start();
$m_id = $_POST['M_ID'];
$select_str1 = "select * from 影片信息表 where 序号 = '$m_id'";
$m_obj1 = new mysql_DB();
$m_result1 = $m_obj1->execSQL($select_str1);
$m_data1 = $m_result1->fetch_assoc();
$m_name = $m_data1['片名'];
$_SESSION['c_mn'] = $m_name;
$m_director = $m_data1['导演'];
$m_swriter = $m_data1['编剧'];
$m_mactor = $m_data1['主演'];
$m_type = $m_data1['类型'];
$m_pCoA = $m_data1['制片国家/地区'];
$m_sCoA = $m_data1['上映国家/地区'];
$m_language = $m_data1['语言'];
$m_sDate = $m_data1['上映日期'];
$m_time = $m_data1['片长'];
$m_oname = $m_data1['又名'];
$m_IMDb = $m_data1['IMDb'];
$m_bi = $m_data1['剧情简介'];
$select_str2 = "select time_format(开始时间, '%H:%i'), time_format(结束时间, '%H:%i'), 观影厅, 票价, 剩余票数 from 场次信息表 where 片名 = '$m_name' order by 开始时间";
$m_obj2 = new mysql_DB();
$m_result2 = $m_obj2->execSQL($select_str2);
$m_data2 = $m_result2->fetch_all();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <link rel="icon" href="../image/logo.png" type="image/png">
    <title>小谢电影网：电影</title>
    <link rel="stylesheet" href="../css/Movie_ShowInterface.css" type="text/css">
    <script src="../js/Movie_ShowInterface.js"></script>
    <script src="../js/Dim_Search.js"></script>
</head>

<body>
    <div id="main">
        <div id="header">
            <img id="img1_header" src="../image/logo.png">
            <span id="span1_header">小谢电影网</span>
            <a class="a1" href="User_MovieInterface.php"><span id="span2_header">电影</span></a>
            <a class="a1" href="User_NewInterface.php"><span class="span3_header">新闻</span></a>
            <a class="a1" href="User_MineInterface.php"><span class="span3_header">我的</span></a>
            <input type="search" id="search_text" placeholder="请输入内容进行搜索" onkeydown="search()">
            <span id="span4_header">欢迎您，用户<?= $_SESSION['un'] ?>！</span>
            <a class="a1" href="Session_Destroy.php"><span id='span4_header'>退出</span></a>
        </div>
        <hr>
        <div id="pagebody">
            <div id="mname_msession">
                <h1 id="mname"><?= $m_name ?></h1>
                <h1 id="msession">今日场次</h1>
            </div>
            <div id="mname_mposter">
                <img id="mposter" src=".././image/movie/<?= $m_id ?>.png">
            </div>
            <div id="information">
                <?php
                if ($m_director != null) {
                    echo "<p id='p_information_first'><span class='span_information'>导演：</span><span>{$m_director}</span></p>";
                }
                if ($m_swriter != null) {
                    echo "<p class='p_information_others'><span class='span_information'>编剧：</span><span>{$m_swriter}</span></p>";
                }
                if ($m_mactor != null) {
                    echo "<p class='p_information_others'><span class='span_information'>主演：</span><span>{$m_mactor}</span></p>";
                }
                if ($m_type != null) {
                    echo "<p class='p_information_others'><span class='span_information'>类型：</span><span>{$m_type}</span></p>";
                }
                if ($m_pCoA != null) {
                    echo "<p class='p_information_others'><span class='span_information'>制片国家/地区：</span><span>{$m_pCoA}</span></p>";
                }
                if ($m_language != null) {
                    echo "<p class='p_information_others'><span class='span_information'>语言：</span><span>{$m_language}</span></p>";
                }
                if ($m_sDate != null) {
                    echo "<p class='p_information_others'><span class='span_information'>上映日期：</span><span>{$m_sDate}({$m_sCoA})</span></p>";
                }
                if ($m_time != null) {
                    echo "<p class='p_information_others'><span class='span_information'>片长：</span><span>{$m_time}</span></p>";
                }
                if ($m_oname != null) {
                    echo "<p class='p_information_others'><span class='span_information'>又名：</span><span>{$m_oname}</span></p>";
                }
                if ($m_IMDb != null) {
                    echo "<p class='p_information_others'><span class='span_information'>IMDb：</span><span>{$m_IMDb}</span></p>";
                }
                ?>
            </div>
            <div id="time_quantum">
                    <?php
                    if($m_data2 != null) {
                        echo "<table><tr><th>序号</th><th>场次</th><th>观影厅</th><th>票价</th><th>剩余票数</th><th>操作</th></tr>";
                        foreach ($m_data2 as $key => $value) {
                            $sn = $key + 1;
                            $session_time = '"'.$value[0]."~".$value[1].'"';
                            echo "<tr><td>{$sn}</td><td>{$value[0]}~{$value[1]}</td>
<td>{$value[2]}</td><td>{$value[3]}</td><td>{$value[4]}</td><td><a class='a1' onclick='session_choice($session_time, $value[2], $value[3], $value[4])'>订票</a></td></tr>";
                        }
                        echo "</table>";
                    } else {
                        echo "<p id='time_quantum_p_hint'>暂无场次安排</p>";
                    }
                    ?>
                </table>
            </div>
        </div>
        <div id="brief_introduction">
            <h3><?= $m_name ?>的剧情简介······</h3>
            <p>
                <?= $m_bi ?>
            </p>
        </div>
    </div>
</body>

</html>