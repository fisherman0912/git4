<?php
session_start();
$un = $_SESSION['un'];
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <link rel="icon" href="../image/logo.png" type="image/png">
    <title>小谢电影网：我的</title>
    <link rel="stylesheet" href="../css/User_MineInterface.css" type="text/css">
    <script src="../js/User_MineInterface.js"></script>
    <script src="../js/Dim_Search.js"></script>
</head>

<body>
<div id="main">
    <div id="header">
        <img id="img1_header" src="../image/logo.png">
        <span id="span1_header">小谢电影网</span>
        <a class="a1" href="User_MovieInterface.php"><span id="span2_header">电影</span></a>
        <a class="a1" href="User_NewInterface.php"><span class="span3_header">新闻</span></a>
        <a class="a1" href="User_MineInterface.php"><span class="span3_header">我的</span></a>
        <input type="search" id="search_text" placeholder="请输入内容进行搜索" onkeydown="search()">
        <span id="span4_header" >欢迎您，用户<?= $_SESSION['un'] ?>！</span>
        <a class="a1" href=".././html/Login_Interface.html"><span id="span4_header">退出</span></a>
    </div>
    <hr>
    <div>
        <a href="Alter_Interface.php"><input type="button" id="alter_button" value="修改个人信息"></a>
        <a href="Examine_Interface.php"><input type="button" id="examine_button" value="查看个人订单"></a>
    </div>
</div>
</body>

</html>