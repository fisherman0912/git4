<?php
require 'mysql.php';
$data_un = $_GET['run'];
$check_str = "select 用户名 from 用户信息表 where 用户名 = '$data_un'";
$check_obj = new mysql_DB();
$check_result = $check_obj->execSQL($check_str);
$check_row = $check_result->num_rows;
if($check_row != 0) {
    echo 0;
} else {
    echo 1;
}
?>
