<?php
require 'mysql.php';
session_start();
$select_str1 = "select 片名, 今日票房 from 影片信息表 order by 今日票房 desc limit 5";
$tTickets_obj = new mysql_DB();
$tTickets_result = $tTickets_obj->execSQL($select_str1);
$tTickets_data = $tTickets_result->fetch_all();
$select_str2 = "select 序号 from 影片信息表 where 状态 = 'ing'";
$im_obj = new mysql_DB();
$im_result = $im_obj->execSQL($select_str2);
$im_data = $im_result->fetch_all();
$select_str3= "select 序号 from 影片信息表 where 状态 = 'will'";
$wm_obj = new mysql_DB();
$wm_result = $wm_obj->execSQL($select_str3);
$wm_data = $wm_result->fetch_all();
$page = 1;
$interval = 6;
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <link rel="icon" href="../image/logo.png" type="image/png">
    <title>小谢电影网：电影</title>
    <link rel="stylesheet" href="../css/User_MovieInterface.css" type="text/css">
    <script src="../js/User_MovieInterface.js"></script>
    <script src="../js/Dim_Search.js"></script>
</head>

<body>
    <div id="main">
        <div id="header">
            <img id="img1_header" src="../image/logo.png">
            <span id="span1_header">小谢电影网</span>
            <a class="a1" href="User_MovieInterface.php"><span id="span2_header">电影</span></a>
            <a class="a1" href="User_NewInterface.php"><span class="span3_header">新闻</span></a>
            <a class="a1" href="User_MineInterface.php"><span class="span3_header">我的</span></a>
            <input type="search" id="search_text" placeholder="请输入内容进行搜索" onkeydown="search()">
            <span id="span4_header">欢迎您，用户<?= $_SESSION['un'] ?>！</span>
            <a class="a1" href="Session_Destroy.php"><span id='span4_header'>退出</span></a>
        </div>
        <hr>
        <div id="classification">
            <h3>分类：</h3>
            <span id="全部" class="a1" onclick="classify(this.id, <?= $page ?>, <?= $interval ?>)">全部</span>
            <span id="动作" class="a1" onclick="classify(this.id, <?= $page ?>, <?= $interval ?>)">动作</span>
            <span id="喜剧" class="a1" onclick="classify(this.id, <?= $page ?>, <?= $interval ?>)">喜剧</span>
            <span id="爱情" class="a1" onclick="classify(this.id, <?= $page ?>, <?= $interval ?>)">爱情</span>
            <span id="科幻" class="a1" onclick="classify(this.id, <?= $page ?>, <?= $interval ?>)">科幻</span>
            <span id="悬疑" class="a1" onclick="classify(this.id, <?= $page ?>, <?= $interval ?>)">悬疑</span>
            <span id="恐怖" class="a1" onclick="classify(this.id, <?= $page ?>, <?= $interval ?>)">恐怖</span>
            <span id="治愈" class="a1" onclick="classify(this.id, <?= $page ?>, <?= $interval ?>)">治愈</span>
            <span id="纪录" class="a1" onclick="classify(this.id, <?= $page ?>, <?= $interval ?>)">纪录</span>
        </div>
        <hr>
        <div id="pagebody">
            <div id="content1">
                <form name="ingMovie" action="Movie_ShowInterface.php" method="post">
                    <h1 id="h1_content">正在热映</h1>
                    <?php
                    foreach ($im_data as $key => $value) {
                        if($key == 0 || $key == 4) {
                            echo "<p id='p1_content'>
                        <img class='img1_content' src='../image/movie/{$value[0]}.png'>
                        <button value='im{$key}' onclick='ing_show(this.value)'>购票</button>
                    </p>";
                        } else {
                            echo "<p class='p2_content'>
                        <img class='img1_content' src='../image/movie/{$value[0]}.png'>
                        <button value='im{$key}' onclick='ing_show(this.value)'>购票</button>
                    </p>";
                        }
                    }
                    ?>
                    <input type="hidden" name="M_ID" value="">
                </form>
            </div>
            <div id="rightbar">
                <h1 id="h1_rightbar">今日票房</h1>
                <table id="table_rightbar">
                    <?php
                    foreach ($tTickets_data as $key => $value) {
                        $temp_key = $key + 1;
                        echo "<tr>
                        <td><i style='color: red'>{$temp_key}</i>&nbsp;&nbsp;&nbsp;{$value[0]}
                            <span>{$value[1]}</span></td>
                    </tr>";
                    }
                    ?>
                </table>
            </div>
            <div id="content2">
                <form name="willMovie" action="Movie_ShowInterface.php" method="post">
                    <h1 id="h2_content">即将上映</h1>
                    <?php
                    foreach ($wm_data as $key => $value) {
                        if($key == 0 || $key == 4) {
                            echo "<p id='p3_content'>
                        <img class='img2_content' src='../image/movie/{$value[0]}.png'>
                        <button value='wm{$key}' onclick='will_show(this.value)'>购票</button>
                    </p>";
                        } else {
                            echo "<p class='p4_content'>
                        <img class='img2_content' src='../image/movie/{$value[0]}.png'>
                        <button value='wm{$key}' onclick='will_show(this.value)'>购票</button>
                    </p>";
                        }
                    }
                    ?>
                    <input type="hidden" name="M_ID" value="">
                </form>
            </div>
        </div>
    </div>
</body>

</html>