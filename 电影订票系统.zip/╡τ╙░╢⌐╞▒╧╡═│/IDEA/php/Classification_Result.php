<?php
require 'mysql.php';
session_start();
$type = $_GET['type'];
$page = $_GET['page'];
$interval = $_GET['interval'];
$select_str1 = "select 序号 from 影片分类表 where 类型 = '$type'";
$select_obj1 = new mysql_DB();
$select_result1 = $select_obj1->execSQL($select_str1);
$select_arr1 = $select_result1->fetch_assoc();
$select_arr1 = explode(";", trim($select_arr1['序号'], ";"));
$length = count($select_arr1);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <link rel="icon" href="../image/logo.png" type="image/png">
    <title>小谢电影网：电影</title>
    <link rel="stylesheet" href="../css/Classification_Result.css" type="text/css">
    <script src="../js/Classification_Result.js"></script>
    <script src="../js/Dim_Search.js"></script>
</head>

<body>
    <div id="main">
        <div id="header">
            <img id="img1_header" src="../image/logo.png">
            <span id="span1_header">小谢电影网</span>
            <a class="a1" href="User_MovieInterface.php"><span id="span2_header">电影</span></a>
            <a class="a1" href="User_NewInterface.php"><span class="span3_header">新闻</span></a>
            <a class="a1" href="User_MineInterface.php"><span class="span3_header">我的</span></a>
            <input type="search" id="search_text" placeholder="请输入内容进行搜索" onkeydown="search()">
            <span id="span4_header">欢迎您，用户<?= $_SESSION['un'] ?>！</span>
            <a class="a1" href="Session_Destroy.php"><span id='span4_header'>退出</span></a>
        </div>
        <hr>
        <div id="classification">
            <h3>分类：</h3>
            <span id="全部" class="a1" onclick="classify(this.id, 1, 6)">全部</span>
            <span id="动作" class="a1" onclick="classify(this.id, 1, 6)">动作</span>
            <span id="喜剧" class="a1" onclick="classify(this.id, 1, 6)">喜剧</span>
            <span id="爱情" class="a1" onclick="classify(this.id, 1, 6)">爱情</span>
            <span id="科幻" class="a1" onclick="classify(this.id, 1, 6)">科幻</span>
            <span id="悬疑" class="a1" onclick="classify(this.id, 1, 6)">悬疑</span>
            <span id="恐怖" class="a1" onclick="classify(this.id, 1, 6)">恐怖</span>
            <span id="治愈" class="a1" onclick="classify(this.id, 1, 6)">治愈</span>
            <span id="纪录" class="a1" onclick="classify(this.id, 1, 6)">纪录</span>
        </div>
        <hr>
        <div id="pagebody">
            <div id="content">
                <h1 id="content_h1"><?= $type ?></h1>
                <?php
                if ($select_arr1 != null) {
                    $had_show = ($page - 1) * $interval;
                    if ($length - $had_show < 6) {
                        $interval = $length - $had_show;
                    }
                    for ($i = $had_show; $i < $had_show + $interval; $i++) {
                        $temp_state = substr($select_arr1[$i], 0, 2);
                        if ($temp_state == "im") {
                            $state = "正在上映";
                        } else {
                            $state = "即将上映";
                        }
                        echo "<p class='content_p'>";
                        echo "<img class='content_img' src='../image/movie/{$select_arr1[$i]}.png'>";
                        $select_arr1[$i] = '"'.$select_arr1[$i].'"';
                        if ($state == "正在上映") {
                            echo "<button class='content_p_button1' onclick='show({$select_arr1[$i]})'>正在上映</button>";
                        } else {
                            echo "<button class='content_p_button2' onclick='show({$select_arr1[$i]})'>即将上映</button>";
                        }
                        echo "</p>";
                    }
                }
                $type = '"'.$type.'"';
                if ($length > 6) {
                    if ($page == 1) {
                        echo "<p id='paging1'>";
                        echo "<a class='a1' onclick='next_page({$type}, {$page}, 6)'><span>下一页</span></a>";
                        echo "</p>";
                    }
                    if ($page > 1 && $interval == 6) {
                        echo "<p id='paging2'>";
                        echo "<a class='a1' onclick='previous_page({$type}, {$page}, 6)'><span>上一页</span></a>";
                        echo "<a class='a1' onclick='next_page({$type}, {$page}, 6)'><span>下一页</span></a>";
                        echo "</p>";
                    }
                    if ($page != 1 && $interval < 6) {
                        echo "<p id='paging3'>";
                        echo "<a class='a1' onclick='previous_page({$type}, {$page}, 6)'><span>上一页</span></a>";
                        echo "</p>";
                    }
                }
                ?>
            </div>
        </div>
    </div>
</body>

</html>