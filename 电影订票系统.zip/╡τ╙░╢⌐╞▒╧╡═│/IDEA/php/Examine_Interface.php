<?php
require 'mysql.php';
session_start();
$un = $_SESSION['un'];
$select_str1 = "select date_format(购买时间, '%Y-%m-%d'), 片名, 场次, 观影厅, 座位, 票数, 总额 from 用户订单表 where 用户名 = '$un'";
$select_obj1 = new mysql_DB();
$select_result1 = $select_obj1->execSQL($select_str1);
$select_arr1 = $select_result1->fetch_all();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <link rel="icon" href="../image/logo.png" type="image/png">
    <title>小谢电影网：我的个人订单</title>
    <link rel="stylesheet" href="../css/Examine_Interface.css" type="text/css">
    <script src="../js/Examine_Interface.js"></script>
    <script src="../js/Dim_Search.js"></script>
</head>

<body>
    <div id="main">
        <div id="header">
            <img id="img1_header" src="../image/logo.png">
            <span id="span1_header">小谢电影网</span>
            <a class="a1" href="User_MovieInterface.php"><span id="span2_header">电影</span></a>
            <a class="a1" href="User_NewInterface.php"><span class="span3_header">新闻</span></a>
            <a class="a1" href="User_MineInterface.php"><span class="span3_header">我的</span></a>
            <input type="search" id="search_text" placeholder="请输入内容进行搜索" onkeydown="search()">
            <span id="span4_header" ">欢迎您，用户<?= $_SESSION['un'] ?>！</span>
            <a class="a1" href=".././html/Login_Interface.html"><span id="span4_header">退出</span></a>
        </div>
        <hr>
        <div>
            <h1 id="of_h1">订单信息</h1>
            <?php
            if ($select_arr1 != null) {
                echo "<table id='of_table'><tr><th>购买时间</th><th>片名</th><th>场次</th><th>观影厅</th><th>座位（排-座）</th>
<th>票数</th><th>总额</th></tr>";
                foreach ($select_arr1 as $key => $value) {
                    echo "<tr><td>{$value[0]}</td><td>{$value[1]}</td><td>{$value[2]}</td><td>{$value[3]}</td>
<td>{$value[4]}</td><td>{$value[5]}</td><td>{$value[6]}</td></tr>";
                }
                echo "</table>";
            } else {
                echo "<p id='hint_of'>暂无信息</p>";
            }
            ?>
        </div>
    </div>
</body>

</html>