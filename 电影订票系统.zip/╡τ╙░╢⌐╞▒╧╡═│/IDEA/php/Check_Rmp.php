<?php
require 'mysql.php';
$data_mp = $_GET['rmp'];
$check_str = "select 手机号 from 用户信息表 where 手机号 = '$data_mp'";
$check_obj = new mysql_DB();
$check_result = $check_obj->execSQL($check_str);
$check_row = $check_result->num_rows;
if($check_row != 0) {
    echo 0;
} else {
    echo 1;
}
?>