<?php
require 'mysql.php';
session_start();
$_SESSION['kw'] = $_GET['kw'];
$keyword = $_SESSION['kw'];
$select_str1 = "select * from 影片信息表 where 片名 like '%$keyword%'";
$select_obj1 = new mysql_DB();
$select_result1 = $select_obj1->execSQL($select_str1);
$select_arr1 = $select_result1->fetch_all();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <link rel="icon" href="../image/logo.png" type="image/png">
    <title>小谢电影网：电影</title>
    <link rel="stylesheet" href="../css/Search_ShowInterface.css" type="text/css">
    <script src="../js/Search_ShowInterface.js"></script>
    <script src="../js/Dim_Search.js"></script>
</head>

<body>
    <div id="main">
        <div id="header">
            <img id="img1_header" src="../image/logo.png">
            <span id="span1_header">小谢电影网</span>
            <a class="a1" href="User_MovieInterface.php"><span id="span2_header">电影</span></a>
            <a class="a1" href="User_NewInterface.php"><span class="span3_header">新闻</span></a>
            <a class="a1" href="User_MineInterface.php"><span class="span3_header">我的</span></a>
            <input type="search" id="search_text" placeholder="请输入内容进行搜索" onkeydown="search()">
            <span id="span4_header">欢迎您，用户<?= $_SESSION['un'] ?>！</span>
            <a class="a1" href="Session_Destroy.php"><span id='span4_header'>退出</span></a>
        </div>
        <hr>
        <div>
            <h1 id="sr_h1">搜索结果</h1>
            <?php
            if ($select_arr1 != null) {
                foreach ($select_arr1 as $key => $value) {
                    echo "<div id='sr'>";
                    $MID = '"'.$value[1].'"';
                    echo "<img id='sr_img' src='../image/movie/{$value[1]}.png' onclick='enter($MID)'>";
                    echo "<span id='sr_span'>片名：{$value[2]}</span>";
                    echo "<span id='sr_span'>导演：{$value[3]}</span>";
                    echo "<span id='sr_span'>编剧：{$value[4]}</span>";
                    echo "<span id='sr_span'>主演：{$value[5]}</span>";
                    echo "<span id='sr_span'>类型：{$value[6]}</span>";
                    echo "<span id='sr_span'>上映日期：{$value[10]}({$value[8]})</span>";
                    echo "<span id='sr_span'>累计票房：{$value[16]}</span>";
                    echo "</div>";
                }
            }
            ?>
        </div>
    </div>
</body>

</html>