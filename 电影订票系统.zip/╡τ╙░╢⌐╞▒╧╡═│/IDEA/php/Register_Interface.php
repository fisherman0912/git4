<?php
require 'mysql.php';
$mp = $_POST['rmp'];
$pw = $_POST['rpw'];
$un = $_POST['run'];
$gender = $_POST['rgender'];
$bd = $_POST['rbd'];
$ic = $_POST['ric'];
$insert_str = "insert into 用户信息表(手机号, 密码, 用户名, 性别, 出生日期, 身份证号) values('$mp', '$pw', '$un', '$gender', '$bd', '$ic')";
$insert_obj = new mysql_DB();
$insert_result = $insert_obj->execSQL($insert_str);
echo "<script>alert('注册成功！');parent.location.href='../html/Login_Interface.html';</script>";
?>