<?php
class mysql_DB {
    private $db = null;
    private function Connection() {
        if($this->db === null) {
            $this->db = new mysqli("127.0.0.1", "root", "", "m_bt_s") or die($this->db->error);
            $this->db->query("SET NAMES 'utf8'");
        }
    }

    public function execSQL($query) {
        $this->Connection();
        $result = $this->db->query($query) or die($this->db->error);
        return $result;
    }
}
?>