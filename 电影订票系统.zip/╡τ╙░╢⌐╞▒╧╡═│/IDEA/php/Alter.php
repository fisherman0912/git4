<?php
require 'mysql.php';
session_start();
$old_un = $_SESSION['un'];
$new_un = $_POST['aun'];
$new_gender = $_POST['agender'];
$new_bd = $_POST['abd'];
$update_str1 = "update 用户信息表 set 用户名 = '$new_un', 性别 = '$new_gender', 出生日期 = '$new_bd' where 用户名 = '$old_un'";
$update_obj1 = new mysql_DB();
$update_result1 = $update_obj1->execSQL($update_str1);
$_SESSION['un'] = $new_un;
echo "<script>alert('修改成功！');parent.location.href='User_MineInterface.php';</script>";
?>