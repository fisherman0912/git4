<?php
require "mysql.php";
session_start();
$_SESSION['c_ms'] = $_GET['s_c'];
$_SESSION['c_ma'] = $_GET['a_c'];
$_SESSION['c_mp'] = $_GET['p_t'];
$_SESSION['c_mt'] = $_GET['r_t'];
$c_mn = $_SESSION['c_mn'];
$c_ms = $_SESSION['c_ms'];
$c_ma = $_SESSION['c_ma'];
$c_mp = $_SESSION['c_mp'];
$c_mt = $_SESSION['c_mt'];
$select_str1 = "select 已售座位 from 座位信息表 where 片名 = '$c_mn' and 场次 = '$c_ms' and 观影厅 = '$c_ma'";
$select_obj1 = new mysql_DB();
$select_result1 = $select_obj1->execSQL($select_str1);
$temp_select_array1 = $select_result1->fetch_assoc();
$select_array1 = explode(";", trim($temp_select_array1['已售座位'], ";"));
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <link rel="icon" href="../image/logo.png" type="image/png">
    <title>小谢电影网：电影</title>
    <link rel="stylesheet" href="../css/Seat_ChooseInterface.css" type="text/css">
    <script src="../js/Seat_ChooseInterface.js"></script>
    <script src="../js/Dim_Search.js"></script>
    <script src="../js/jquery-3.3.1.js"></script>
    <script>
        $(document).ready(function () {
            document.getElementById("stButton_pay").disabled = true;
            var temp_array = eval(<?php echo json_encode($select_array1);?>);
            for (let i = 0; i < <?= count($select_array1) ?>; i++) {
                var id = temp_array[i];
                document.getElementById(id).src = "../image/seat_sold.png";
                var row_col = id.split("-");
                seat_check[row_col[0] - 1][row_col[1] - 1] = 2;
            }
        });
    </script>
</head>

<body>
    <div id="main">
        <div id="header">
            <img id="img1_header" src="../image/logo.png">
            <span id="span1_header">小谢电影网</span>
            <a class="a1" href="User_MovieInterface.php"><span id="span2_header">电影</span></a>
            <a class="a1" href="User_NewInterface.php"><span class="span3_header">新闻</span></a>
            <a class="a1" href="User_MineInterface.php"><span class="span3_header">我的</span></a>
            <input type="search" id="search_text" placeholder="请输入内容进行搜索" onkeydown="search()">
            <span id="span4_header">欢迎您，用户<?= $_SESSION['un'] ?>！</span>
            <a class="a1" href="Session_Destroy.php"><span id='span4_header'>退出</span></a>
        </div>
        <hr>
        <h1 id="seat_table_h1">座位图</h1>
        <h3 id="seat_table_h3">屏幕</h3>
        <div id="seat_table">
            <?php
            $i = 0;
            while ($i < 40) {
                $row = (floor($i / 8)) + 1;
                $col = $i % 8 + 1;
                echo "<img src='../image/seat.png' id='{$row}-{$col}' onclick='seat_choose($row, $col)'>";
                $i++;
            }
            ?>
            <button id="stButton_sure" name="sure" onclick="seat_show()">确定</button>
            <button id="stButton_pay" name="pay" onclick="seat_pay()">付款</button>
            <h4 id='seat_table_h4'>您已选择：</h4>
            <p id='seat_table_p1'><span id='seat_selected'>&nbsp;</span></p>
        </div>
    </div>
</body>

</html>
