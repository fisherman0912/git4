<?php
require 'mysql.php';
session_start();
$un = $_SESSION['un'];
$select_str1 = "select * from 用户信息表 where 用户名 = '$un'";
$select_obj1 = new mysql_DB();
$select_result1 = $select_obj1->execSQL($select_str1);
$select_arr1 = $select_result1->fetch_assoc();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <link rel="icon" href="../image/logo.png" type="image/png">
    <title>小谢电影网：我的个人订单</title>
    <link rel="stylesheet" href="../css/Alter_Interface.css" type="text/css">
    <script src="../js/Alter_Interface.js"></script>
    <script src="../js/Dim_Search.js"></script>
</head>

<body>
    <div id="main">
        <div id="header">
            <img id="img1_header" src="../image/logo.png">
            <span id="span1_header">小谢电影网</span>
            <a class="a1" href="User_MovieInterface.php"><span id="span2_header">电影</span></a>
            <a class="a1" href="User_NewInterface.php"><span class="span3_header">新闻</span></a>
            <a class="a1" href="User_MineInterface.php"><span class="span3_header">我的</span></a>
            <input type="search" id="search_text" placeholder="请输入内容进行搜索" onkeydown="search()">
            <span id="span4_header" ">欢迎您，用户<?= $_SESSION['un'] ?>！</span>
            <a class="a1" href=".././html/Login_Interface.html"><span id="span4_header">退出</span></a>
        </div>
        <hr>
        <div id="div2">
            <form action="Alter.php" method="post">
                <h1 id="alter_h1">个人信息</h1>
                <p>
                    <span id="alter_span1">手机号：</span>
                    <span><?= $select_arr1['手机号'] ?></span>
                </p>
                <p>
                    <span id="alter_span1"></span>
                </p>
                <p>
                    <span id="alter_span1">密码：</span>
                    <span><?= $select_arr1['密码'] ?></span>
                </p>
                <p>
                    <span id="alter_span1"></span>
                </p>
                <p>
                    <span id="alter_span1">用户名：</span>
                    <input type="text" id="aun" name="aun" maxlength="5" placeholder="<?= $select_arr1['用户名'] ?>" required>
                </p>
                <p>
                    <span id="alter_span1">&nbsp;</span>
                    <span id="show_caun">&nbsp;</span>
                </p>
                <p>
                    <span id="alter_span1">性别：</span>
                    <select name="agender">
                        <option value="男" selected>男</option>
                        <option value="女">女</option>
                    </select>
                </p>
                <p>
                    <span id="alter_span1">&nbsp;</span>
                </p>
                <p>
                    <span id="alter_span1">出生日期：</span>
                    <input type="date" id="abd" name="abd">
                </p>
                <p>
                    <span id="alter_span1">&nbsp;</span>
                </p>
                <p>
                    <span id="alter_span1">身份证号：</span>
                    <span><?= $select_arr1['身份证号'] ?></span>
                </p>
                <p>
                    <span id="alter_span1"></span>
                </p>
                <p>
                    <a href="User_MineInterface.php"><input type="button" value="返回"></a>
                    <input type="submit" id="alter" value="修改">
                </p>
            </form>
        </div>
    </div>
</body>

</html>
