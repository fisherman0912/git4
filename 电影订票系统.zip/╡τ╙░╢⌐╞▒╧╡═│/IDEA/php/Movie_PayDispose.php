<?php
require 'mysql.php';
session_start();
$un = $_SESSION['un'];
$_SESSION['s_c'] = $_GET['s_c'];
$_SESSION['s_fB'] = $_GET['s_fB'];
$c_mn = $_SESSION['c_mn'];
$c_ms = $_SESSION['c_ms'];
$c_ma = $_SESSION['c_ma'];
$c_mp = $_SESSION['c_mp'];
$c_mt = $_SESSION['c_mt'];
$temp1 = explode(",", $_SESSION['s_c']);
$temp2 = explode(",", $_SESSION['s_fB']);
$seat_condition = array();
reset($temp1);
$i1 = 0;
$j1 = 0;
foreach ($temp1 as $key => $value) {
    $seat_condition[$i1][$j1] = $value;
    $j1++;
    if (($key + 1) % 8 == 0) {
        $i1++;
        $j1 = 0;
    }
}
$seat_fBook = array();
reset($temp2);
$i2 = 0;
$j2 = 0;
$count2 = 0;
$choice = "";
foreach ($temp2 as $key => $value) {
    $seat_fBook[$i2][$j2] = $value;
    if($value == 1) {
        $count2++;
        $temp_str = ($i2 + 1)."-".($j2 + 1);
        $choice = $choice.$temp_str.";";
    }
    $j2++;
    if (($key + 1) % 8 == 0) {
        $i2++;
        $j2 = 0;
    }
}
$sold = "";
for ($i = 0; $i < 5; $i++) {
    for ($j = 0; $j < 8; $j++) {
        if ($seat_condition[$i][$j] == 2) {
            $temp_str1 = ($i + 1)."-".($j + 1);
            $sold = $sold.$temp_str1.";";
        }
    }
}
$update_str1 = "update 座位信息表 set 已售座位 = '$sold' where 片名 = '$c_mn' and 场次 = '$c_ms' and 观影厅 = '$c_ma'";
$update_obj1 = new mysql_DB();
$update_result1 = $update_obj1->execSQL($update_str1);
$update_str2 = "update 场次信息表 set 剩余票数 = '$c_mt' - '$count2' where 片名 = '$c_mn' and 观影厅 = '$c_ma'";
$update_obj2 = new mysql_DB();
$update_result2 = $update_obj2->execSQL($update_str2);
$update_str3 = "update 影片信息表 set 今日票房 = 今日票房 + '$count2', 累计票房 = 累计票房 + '$count2' where 片名 = '$c_mn'";
$update_obj3 = new mysql_DB();
$update_result3 = $update_obj3->execSQL($update_str3);
$cost = $c_mp * $count2;
$insert_str1 = "insert into 用户订单表(用户名, 购买时间, 片名, 场次, 观影厅, 座位, 票数, 总额) values('$un', now(), '$c_mn', '$c_ms', '$c_ma', 
'$choice', '$count2', '$cost')";
$insert_obj1 = new mysql_DB();
$insert_result1 = $insert_obj1->execSQL($insert_str1);
echo "<script>alert('付款成功！共消费金额{$cost}元！');parent.location.href='User_MovieInterface.php';</script>";
?>