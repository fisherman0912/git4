<?php
session_start();
session_destroy();
echo "<script>alert('您已成功退出！');parent.location.href='../html/Login_Interface.html';</script>";
?>